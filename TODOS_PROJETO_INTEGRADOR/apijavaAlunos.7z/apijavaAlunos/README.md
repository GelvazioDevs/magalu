# Usuario: - ok
* Campos:
    * id:Serial
    * email:String
    * senha:String
    * nome:String
    
# Cliente - ok
* Campos:
    * id: Serial
    * nome: String
    * email:String
    * celular:String
    * cidade:String
    
    * Model=>Cliente.java
    * Repository=>
    * Controller=>
# Produto - ok
* Campos
    * id: Serial
    * descricao:String
    * preco:double
    * estoque:int

# Cidade - ok
* Campos:
  * id:Serial
  * Estado:String(Sigla)
  * Descrição
  * regiao_id(Id da Região)

# Região - ok
* Campos
  * id:Serial
  * descrição:String

# Vendedor - ok
* Campos:
  * id:Serial
  * nome:
  * taxacomissao:double

# FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - 
# FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - 
# FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - 
# FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - 

# Pedidos  
# Nota de Entrada 
# Nota de Venda


tales.gois@alunos.sc.senac.br





