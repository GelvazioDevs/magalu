# TESTANDO API




# Usuario: - ok

* Campos:
    * id:Serial
    * email:String
    * senha:String
    * nome:String
    
# Cliente - ok
* Campos:
    * id: Serial
    * nome: String
    * email:String
    * celular:String
    * cidade:String
    
    * Model=>Cliente.java
    * Repository=>
    * Controller=>
# Produto - ok
* Campos
    * id: Serial
    * descricao:String
    * preco:double
    * estoque:int

# Cidade - ok
* Campos:
  * id:Serial
  * Estado:String(Sigla)
  * Descrição
  * regiao_id(Id da Região)

# Região - ok
* Campos
  * id:Serial
  * descrição:String

# Vendedor - ok
* Campos:
  * id:Serial
  * nome:
  * taxacomissao:double

# FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - 
# FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - 
# FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - 
# FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - # FATURAMENTO - 

# Pedidos  
# Nota de Entrada 
# Nota de Venda

# CONFERENCIA CERTIFICADOS ROCKETSEAT - 01-07-2025
# CURSO CSS HTML E JAVASCRIPT

CARLOS AMAURY  - OK
BERNARDO WILL  - OK
EDUARDO SOUZA  - FALTOU O PROJETO FINAL, VER DEPOIS
JUNIOR FELTRIN - OK
LUIZ           - OK
NATASHA        - OK
JOAO           - OK 
PEDRO          - FEZ MAS NAO MANDOU O LINK
PABLO          - OK 
NICOLE         - OK 

# CURSO JAVA COM SPRINGBOOT - ENTREGAR ATE 11-07-2025
CARLOS AMAURY  - OK
BERNARDO WILL  - 
EDUARDO SOUZA  - 
JUNIOR FELTRIN - OK
LUIZ           - 
NATASHA        -
JOAO           - OK 
PEDRO          - 
PABLO          - FALTA MANDAR
NICOLE         - 







